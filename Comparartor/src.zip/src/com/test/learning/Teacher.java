package com.test.learning;

public interface Teacher {
   public String getTopic();
}
