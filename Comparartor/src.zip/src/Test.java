
public class Test {
	
	public void operation(Operation opr)
	{
		opr.change(235);
	}
       
}
